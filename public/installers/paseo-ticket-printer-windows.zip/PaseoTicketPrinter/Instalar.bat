@echo off
powershell.exe -ExecutionPolicy Bypass -File "%~dp0printer-connector\install-windows.ps1"
pause
